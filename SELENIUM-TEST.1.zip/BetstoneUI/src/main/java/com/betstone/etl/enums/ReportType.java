package com.betstone.etl.enums;

public enum ReportType {
    ALL_GAME_PROFIT,
    SCORECARD_EGM,
    MYSTERY;
}
